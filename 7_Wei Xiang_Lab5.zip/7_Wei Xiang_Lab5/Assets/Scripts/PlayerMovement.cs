﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class PlayerMovement : MonoBehaviour
{
    public float Speed;
    public Rigidbody playerRigidbody;
    public float Scores;
    public TextMesh ScoreTxt;
    private float numberOfScore;

    // Start is called before the first frame update
    void Start()
    {
        numberOfScore = GameObject.FindGameObjectsWithTag("Coin").Length;
    }

    // Update is called once per frame
    void Update()
    {
        if (Scores==numberOfScore)
        {
            SceneManager.LoadScene("GameWin");
        }
    }


    private void FixedUpdate()
    {
        float MoveHorizontal = Input.GetAxis("Horizontal");
        float MoveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(MoveHorizontal, 0, MoveVertical);
        playerRigidbody.MovePosition(transform.position +movement*Time.deltaTime*Speed);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag.Equals("Coin"))
        {
            Destroy(collision.gameObject);
            Scores++;
            ScoreTxt.text = "Score = " + Scores;
        }
        if (collision.gameObject.tag.Equals("Obstacle"))
        {
            SceneManager.LoadScene("GameLose");
        }
    }
}
